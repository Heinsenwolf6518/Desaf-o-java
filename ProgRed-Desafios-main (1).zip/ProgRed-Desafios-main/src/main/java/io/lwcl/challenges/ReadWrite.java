package io.lwcl.challenges;

public class ReadWrite {

    /* Desafío 7: Lectura y escritura de archivos
        Crear una aplicación que lea y escriba datos en un archivo de texto.
        Para resolver este desafío, debemos crear un programa que:
        1. Lea datos de un archivo de texto.
        2. Esciba datos en un archivo de texto
     */

}
