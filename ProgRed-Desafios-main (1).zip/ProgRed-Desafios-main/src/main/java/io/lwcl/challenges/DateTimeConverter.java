package io.lwcl.challenges;

public class DateTimeConverter {

    /* Desafío 10: Conversión de fecha y hora
        Crear una aplicación que convierta fechas y horas entre diferentes zonas horarias.
        Para resolver este desafío, debemos crear un programa que:
        1. Pida al usuario que ingrese una fecha y hora.
        2. Convierta la fecha y hora a una zona horaria específica.
        3. Muestre el resultado al usuario
     */
}
