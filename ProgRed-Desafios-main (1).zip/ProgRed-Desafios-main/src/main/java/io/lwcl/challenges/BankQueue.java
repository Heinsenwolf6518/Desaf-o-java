package io.lwcl.challenges;

public class BankQueue {

    /* Desafío 8: Simulación de una cola de banco
        Crear una aplicación que simule una cola de banco, con clientes que llegan y son atendidos
        por un cajero.
        Para resolver este desafío, debemos crear un programa que:
        1. Simule una cola de banco con clientes.
        2. Asigne un cajero a cada cliente.
        3. Verifique si un cliente ha sido atendido.
     */

}
