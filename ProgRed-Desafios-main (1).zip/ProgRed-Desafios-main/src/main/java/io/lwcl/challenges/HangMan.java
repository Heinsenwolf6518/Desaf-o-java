package io.lwcl.challenges;

public class HangMan {

    /* Desafío 9: Juego de Ahorcado
        Crear un juego de Ahorcado para un jugador.

        Para resolver este desafío, debemos crear un programa que:
        1. Genere una palabra aleatoria.
        2. Pida al usuario que adivine la palabra.
        3. Verifique si el usuario ha acertado o no.
     */

}
